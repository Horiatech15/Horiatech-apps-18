# -*- coding: utf-8 -*-
# Copyright (c) 2019-Present Droggol Infotech Private Limited. (<https://www.droggol.com/>)

# [Files will be removed in a future version]
# Contains deprecated fields and models

from . import deprecated_v17
from . import deprecated_v16
from . import deprecated_v15
